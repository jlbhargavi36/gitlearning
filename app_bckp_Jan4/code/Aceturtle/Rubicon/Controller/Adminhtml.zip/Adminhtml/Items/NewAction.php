<?php
/**
 * Copyright © 2015 Aceturtle. All rights reserved.
 */

namespace Aceturtle\Rubicon\Controller\Adminhtml\Items;

class NewAction extends \Aceturtle\Rubicon\Controller\Adminhtml\Items
{

    public function execute()
    {
        $this->_forward('edit');
    }
}
