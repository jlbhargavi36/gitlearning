<?php
/**
 * Copyright © 2015 Aceturtle. All rights reserved.
 */

namespace Aceturtle\Rubicon\Controller\Adminhtml\Items;

class Index extends \Aceturtle\Rubicon\Controller\Adminhtml\Items
{
    /**
     * Items list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Aceturtle_Rubicon::rubicon');
        $resultPage->getConfig()->getTitle()->prepend(__('Aceturtle Items'));
        $resultPage->addBreadcrumb(__('Aceturtle'), __('Aceturtle'));
        $resultPage->addBreadcrumb(__('Items'), __('Items'));
        return $resultPage;
    }
}
